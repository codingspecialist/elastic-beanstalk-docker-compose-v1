# elastic-beanstalk docker-compose.yml 로 배포하기

### Github과 GithubAction 없이 수동 배포해보기
- Docker 아마존 리눅스2 환경 생성
- Dockerfile 생성
- docker-compose.yml 생성
- 포트 80:8080 포워딩 하기
- 로컬에서 빌드하기
```gradle
  ./gradlew clean build
```